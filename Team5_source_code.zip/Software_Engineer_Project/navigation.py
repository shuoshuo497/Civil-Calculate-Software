import subprocess
import sys
from PySide2.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QLabel

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("主界面")
        self.setGeometry(100, 100, 300, 200)

        layout = QVBoxLayout()

        self.btn_node_coordinates = QPushButton("结点坐标作图", self)
        self.btn_node_coordinates.clicked.connect(self.open_truss_drawing)
        layout.addWidget(self.btn_node_coordinates)

        self.btn_assemble_rods = QPushButton("图形界面作图")
        self.btn_assemble_rods.clicked.connect(self.open_rod_assembly)
        layout.addWidget(self.btn_assemble_rods)

        self.setLayout(layout)

    def open_truss_drawing(self):
        self.close()
        subprocess.run(['python', f'node_assembly.py'])
        sys.exit()

    def open_rod_assembly(self):
        self.close()
        subprocess.run(['python', f'truss_drawing.py'])
        sys.exit()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec_())