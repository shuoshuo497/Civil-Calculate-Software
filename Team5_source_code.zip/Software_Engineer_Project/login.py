import mysql.connector
import sys  # 导入系统模块
from PySide2.QtWidgets import QApplication, QWidget, QInputDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, \
    QPushButton, QMessageBox, QTableWidget, QTableWidgetItem, QComboBox, QDialog, QMainWindow
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from navigation import MainWindow

login_connection = {
    'host': 'localhost',
    'port': 3306,
    'database': 'civil_structure',
    'user': 'root',
    'password': '3489796033Lyh'} #本地电脑连接到刘洋昊2150218的mysql数据库
#其他电脑访问会连接失败，请直接运行“navigation.py”文件，不影响后续功能的使用。

class LoginWindow(QWidget):  # 登录页面类
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Login")  # 设置登录页面标题

        layout = QVBoxLayout()  # 创建垂直布局

        self.username_label = QLabel("用户名:")  # 创建用户名标签
        layout.addWidget(self.username_label)  # 将用户名标签添加到布局中

        self.username_input = QLineEdit()  # 创建用户名输入框
        layout.addWidget(self.username_input)  # 将用户名输入框添加到布局中

        self.password_label = QLabel("密码:")  # 创建密码标签
        layout.addWidget(self.password_label)  # 将密码标签添加到布局中

        self.password_input = QLineEdit()  # 创建密码输入框
        self.password_input.setEchoMode(QLineEdit.Password)  # 设置密码输入框为密码模式
        layout.addWidget(self.password_input)  # 将密码输入框添加到布局中

        self.login_button = QPushButton("登录")  # 创建登录按钮
        self.login_button.clicked.connect(self.login)  # 连接按钮点击事件到登录方法
        layout.addWidget(self.login_button)  # 将登录按钮添加到布局中

        self.register_button = QPushButton("注册")  # 创建注册按钮
        self.register_button.clicked.connect(self.register)  # 连接按钮点击事件到注册方法
        layout.addWidget(self.register_button)  # 将注册按钮添加到布局中

        self.setLayout(layout)  # 设置布局
        self.adjustSize()  # 调整窗口大小

    def user_authentication(self, username, password):
        connection = mysql.connector.connect(**login_connection)
        cursor_login = connection.cursor()
        query = "SELECT snum FROM civil_structure.login WHERE snum = %s AND scode = %s"
        cursor_login.execute(query, (username,password))
        result = cursor_login.fetchone()

        cursor_login.close()
        connection.close()

        return result is not None

    def register_authentication(self, username):
        connection = mysql.connector.connect(**login_connection)
        cursor_register = connection.cursor()
        query = "SELECT snum FROM civil_structure.login WHERE snum = %s"
        cursor_register.execute(query, (username,))
        result = cursor_register.fetchone()

        cursor_register.close()
        connection.close()

        return result is not None

    def user_register(self, username, password):
        try:
            connection = mysql.connector.connect(**login_connection)
            cursor_register = connection.cursor()
            query = "insert into civil_structure.login(snum,scode) values(%s, %s)"
            cursor_register.execute(query, (username, password))
            connection.commit()  #提交事务
            cursor_register.close()
            return True
        except mysql.connector.Error as error:
            print("注册失败", error)
            return False

    def login(self):  # 登录方法
        snum = self.username_input.text()  # 获取用户名输入框的文本
        scode = self.password_input.text()  # 获取密码输入框的文本
        if self.user_authentication(snum, scode):# 如果用户名在用户数据库中且密码正确
            self.close()# 隐藏登录页面
            print('11')
            #self.main_window = MainWindow(snum)  # 创建主页面，传入snum作为username
            self.main_window = MainWindow()
            self.main_window.show()  # 显示主页面
        else:
            QMessageBox.warning(self, "登录失败", "用户名或者密码不正确，请重新输入！")

    def register(self):
        snum = self.username_input.text()  # 获取用户名输入框的文本
        scode = self.password_input.text()  # 获取密码输入框的文本
        if self.register_authentication(snum):
            QMessageBox.warning(self, "注册失败", "用户已注册！")  # 如果用户名已存在
        elif self.user_register(snum, scode):
            QMessageBox.information(self, "注册成功", "用户注册成功，请登录！")  # 注册成功
        else:
            QMessageBox.warning(self, "注册失败", "注册失败！")

if __name__ == "__main__":  # 如果运行的是当前脚本
    app = QApplication(sys.argv)  # 创建应用程序
    window = LoginWindow()  # 创建登录页面
    window.show()  # 显示登录页面
    sys.exit(app.exec_())  # 运行应用程序