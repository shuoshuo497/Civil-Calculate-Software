
import sys
from login import LoginWindow

from PySide2 import QtWidgets, QtGui, QtCore




def main():


    app = QtWidgets.QApplication(sys.argv)

    login_window = LoginWindow()
    login_window.show()


    sys.exit(app.exec_())


if __name__ == "__main__":

    main()